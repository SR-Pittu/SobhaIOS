//
//  ViewController.swift
//  PrasadamListApp
//
//  Created by Prasadam,Udayasri on 3/3/23.
//

import UIKit

class ListVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }
    var ct = 0
    var display = "List of grocery items:\n"

    @IBOutlet weak var listTV: UITextView!
    
    @IBOutlet weak var itemTF: UITextField!
    
    
    @IBOutlet weak var itemQuantityTF: UITextField!
    
    
    @IBOutlet weak var itemNumTF: UITextField!
    
    @IBAction func addToList(_ sender: UIButton) {
        
        ct+=1
        display +=  "\(ct). \(self.itemTF.text!)  - \(self.itemQuantityTF.text!)\n"
        listTV.text = display
    }
    
    @IBOutlet weak var addBTN: UIButton!
    
    
    @IBAction func clear(_ sender: UIButton) {
        self.itemTF.text = ""
        self.itemQuantityTF.text = ""
        self.itemNumTF.text = ""
        self.listTV.text = "Please enter the item name and quantity, and click on the plus sign to add the item to the grocery list."
    }
  
    @IBOutlet weak var clearBTN: UIButton!
    
    @IBAction func deleteFromList(_ sender: UIButton) {
        var dlt = [String]()
        dlt.append(self.listTV.text!)
        if(!dlt.isEmpty)
        {
            dlt.remove(at: 0)
        }
    }
    
    
    @IBOutlet weak var deleteBTN: UIButton!
    
    
    
}


//
//  Grocery.swift
//  GroceryAppProject
//
//  Created by Pittu,Sobhareddy on 4/19/23.
//

import Foundation

struct Grocery{
    var category = ""
    var items:[Items] = []
}

struct Items{
    var itemName = ""
    var itemdetails = ""
    var itemQuantity = ""
}

let item = Items(itemName: "Eggs", itemdetails: "ASDFGH", itemQuantity: "20")
let g1 = Grocery(category: "Vegtables", items: [item])

let g2 = Grocery(category: "Meat", items: [item])

let g3 = Grocery(category: "Sea Food", items:  [item])

let g4 = Grocery(category: "Dairy Products", items:  [item])

let g5 = Grocery(category: "Frozen", items:  [item])

let g6 = Grocery(category: "Instant", items:  [item])

let g7 = Grocery(category: "Dry Goods", items: [item])

let g8 = Grocery(category: "Seasoning", items: [item])

let g9 = Grocery(category: "Beverages", items: [item])

let g10 = Grocery(category: "Canned", items: [item])

let g11 = Grocery(category: "Fruits", items: [item])

let g12 = Grocery(category: "Bakery", items: [item])

let g13 = Grocery(category: "Household", items: [item])

let g14 = Grocery(category: "Snacks", items: [item])

let g15 = Grocery(category: "Spreads", items: [item])

let g16 = Grocery(category: "Alcohol", items: [item])

let g17 = Grocery(category: "Baby Food", items: [item])


let grooceriesArray = [g1,g2,g3,g4,g5,g6,g7,g8,g9,g10,g11,g12,g13,g14,g15,g16,g17]
